function [xout] = constrain(xin, xmin, xmax)
% function [xout] = constrain(xin, xmin, xmax)
%   arduino's constrain function, xmin<=xout<=xmax
xout = xin;
xout(xout < xmin) = xmin;
xout(xout > xmax) = xmax;
end

% testing: a = -5:15, b = constrain(a,0,10)