%% script oscope2.m -- first version of an Arduino oscilloscope display
% 3jan23 BR, Arduino running oscope1.ino, command set = b and p

% Notes: 1) make sure oscope1 is running reliably before implementing this --
% because try/catch hides errors making it harder to debug
% 2) Slow down the baud rate to 115200/2 in both the IDE and here if that
% helps reliability. 3) Edit the arduino serial port appropriate for your
% hardware.

if ~exist('runBtn','var') || ~isvalid(runBtn) % add the button
    runBtn = uicontrol('style','radiobutton','string','run','units', ...
        'normalized','position',[.13 .93 .1 .04],'Callback', 'pscope2');
end
if ~exist('ard','var') % initalize arduino
    disp('initializing arduino ...')
    ports = serialportlist; % works for me, substitute appropriate port for yours
    ard = serialport(ports(end),115200,'Timeout',2); 
    clear ports; % clean up workspace
    pause(2); % time for Arduino to boot
end
if ~exist('runOnce','var'), runOnce = true; end

while runBtn.Value || runOnce
    writeline(ard,'b'); pause(.01);
    try
        bin = read(ard,2002,'uint16');
        dt = bitshift(bin(2002),16)+bin(2001); % microseconds
        data = reshape(bin(1:2000),2,1000)' - 1;
        t = linspace(0,dt/1000,1000)';
        plot(t, data, '.-'); grid;
        xlabel('msec'); ylabel('ADU')
%         sr = length(data)/dt*1e6; % sample rate (#/sec)
%         aspectrum(data, sr);
%         xlabel('frequency / Hz'); ylabel('amplitude / ADU')
    catch
        flush(ard);
        fprintf('.');
    end
    runOnce = false;
    displayfps;
end