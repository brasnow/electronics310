function zparallel = zp(z1, z2)
% function zparallel = zp(z1, z2)
% returns z1 .* z2 ./ (z1 + z2), the parallel impedance
 
% 17 mar 21 BR
 
zparallel = z1 .* z2 ./ (z1 + z2); 
end