%% script oscope1.m -- first version of an Arduino oscilloscope display
% 3jan23 BR, Arduino running oscope1.ino, command set = b and p

if ~exist('runBtn','var') || ~isvalid(runBtn) % add a button once
    runBtn = uicontrol('style','radiobutton','string','run','units', ...
        'normalized','position',[.13 .93 .1 .04],'Callback', 'oscope1');
end
if ~exist('ard','var') % initalize arduino
    disp('initializing arduino ...')
    ports = serialportlist; % open the right one
    ard = serialport(ports(end),115200/2,'Timeout',2); % match speed to Arduino
    readline(ard) % wait for Arduino to reboot
    vref = input('Enter Arduino''s vref (in Volts): ');
end

while runBtn.Value 
    writeline(ard,'b'); pause(.01);
    bin = read(ard,802,'uint16');
    data = reshape(bin(1:800),2,400)';
    plot(data, '.-'); grid;
    xlabel('sample #'); ylabel('voltage/ADU')
end
