function displayfps()
% measure & display frame refresh rate
    persistent frame ttime lblFPS
    
    if isempty(lblFPS) || ~isvalid(lblFPS) % initialize
        ttime = tic; frame = 0;
        lblFPS = uicontrol('Style','Text','String','0 FPS', ...
            'Tag','FPS','Units','normalized','Position', ...
            [.01  .05  .08  .03],'FontSize',10,'FontName','times');
        return;
    end    
    frame = frame + 1;
    if frame == 5 
        fps = 5 / toc(ttime);
        set(lblFPS,'String', sprintf('%2.1f FPS', fps));
        ttime = tic; frame = 0;
    end
end
