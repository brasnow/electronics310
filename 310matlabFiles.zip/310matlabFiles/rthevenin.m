function Rth = rthevenin(Vth, Vl, Rl)
% function Rth = rthevenin(Vthevenin, Vload, Rload)
% compute Thevenin resistance of an ideal power supply with Thevenin
% (open circuit) voltage Vthevenin, measured voltage Vload under load
%  with a resistance Rload across it

% 29 sept 22 BR -- just got tired of solving the voltage divider eqn:
% Vl = Vth * Rl / (Rl + Rth) for rth. 

persistent Rload
if nargin == 3, Rload = Rl; end

Rth = (Vth - Vl)*Rload ./ Vl;