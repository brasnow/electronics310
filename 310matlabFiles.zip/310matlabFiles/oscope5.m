%% oscope5.m -- 20nov22 using arddeskew instead of spline
%% oscope4.m -- 20 nov 22 putting variables in dat structure to reduce clutter
%   also dat.ampl is now complex, not abs
% using runBtn.UserData for runOnce
% trim has to use channel 1, not default channel end
%% oscope3.m -- added title with freq, ampls, phase diff, and spline deskew
%% oscope2.m -- added trim for triggering
%% script oscope1.m -- first version of an Arduino oscilloscope display
% 16oct22 BR, Arduino running oscope1, command set = b, p, s
if ~exist('runBtn','var') || ~isvalid(runBtn)  % add the button once
    runBtn = uicontrol('style','radiobutton','string','run','units', ...
        'normalized','position',[.13 .93 .1 .04]);
    runBtn.Callback = 'oscope5';
    runBtn.UserData = true; % using this field for runOnce
end
if ~exist('ard','var') % initalize arduino
    disp('initializing arduino ...')
    ports = serialportlist;
    ard = serialport(ports{end},115200);
    ard.Timeout = 2;
    configureTerminator(ard, 0);
    clear ports;
    pause(2); % time to boot
end

while runBtn.Value || runBtn.UserData
    writeline(ard,'b'); 
    try
        dat.bin = read(ard,804,'int16');
        dat.dt = bitshift(dat.bin(802),16)+dat.bin(801); % microseconds
        dat.raw = reshape(dat.bin(1:800),2,400)' - 1;
        [dat.data, dat.npds] = trim(dat.raw, 420, -1, 1); % adjust 2nd arg = ADU with steepest slope
        dat.t = linspace(0,dat.dt/1000,400)';
        dat.t = dat.t(1:length(dat.data)); 
        dat.sr = length(dat.raw)/dat.dt*1e6; % sample rate (#/sec)
        dat.freq = dat.sr/(length(dat.data)/dat.npds); % Hz, 1/sec
    dat.data = arddeskew(dat.data, 'fourier'); 
        dat.fd = fft(dat.data); % data was trimmed to npds 
        dat.ampl = dat.fd(dat.npds+1,:) / length(dat.data) * 2;
        dat.theta = rad2deg(angle(dat.fd(dat.npds+1,:)));
    catch
        flush(ard);
        break;
    end
    try   % change data inside the plot is faster
        set(dat.plotHandle(1),'XData',dat.t,'YData',dat.data(:,1));
        set(dat.plotHandle(2),'XData',dat.t,'YData',dat.data(:,2));
        dat.plotHandle(3).String = sprintf('%.2fHz V1=%.2f V2 = %.2f deg=%.2f', ...
            dat.freq, abs(dat.ampl), diff(dat.theta));
    catch
        dat.plotHandle = plot(dat.t, dat.data, '.-');
        xlabel('msec'); ylabel('ADU')
        legend('A0','A1'); grid on;
        dat.plotHandle(3) = title(sprintf('%.2fHz V1=%.2f V2 = %.2f deg=%.2f', ...
            dat.freq, dat.ampl, diff(dat.theta)),'FontSize',12);
    end
    displayfps;
    drawnow;
    runBtn.UserData = false;    % runOnce
end
