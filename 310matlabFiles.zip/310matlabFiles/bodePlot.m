function bodePlot(f,a,fc)
% function bodePlot(frequency, amplitude, fcorner)
% generate a Bode plot in the current figure window
% amplitude is assumed complex and normalized
% 3rd argument draws vertical line at fcorner

% 27oct20  BR
clf;
subplot(2,1,1)
loglog(f,abs(a),'.-')
ylabel('amplitude');
grid; axis tight;
if nargin == 3, plotfc(fc); end

subplot(2,1,2)
semilogx(f, rad2deg(unwrap(angle(a))),'.-')
xlabel('frequency'); ylabel('degrees');
grid; axis tight
if nargin == 3, plotfc(fc); end
end

function plotfc(fc) % plot vertical line at fc
    ax = axis;
    hold on; 
    plot([fc fc], [ax(3) ax(4)], '--c');
    hold off;
end