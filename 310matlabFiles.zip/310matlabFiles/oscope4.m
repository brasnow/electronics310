%% oscope4.m -- 24jan24 putting variables in dat structure to reduce clutter
% using runBtn.UserData for runOnce

if ~exist('runBtn','var') || ~isvalid(runBtn)  % add the button once
    runBtn = uicontrol('style','radiobutton','string','run', ...
        'units','normalized','position',[.13 .93 .1 .04]);
    runBtn.Callback = 'oscope4';
    runBtn.UserData = true; % using this field for runOnce
    dat.skew = uicontrol('Style','popupmenu','Units','normalized',...
        'Position',[.1 .01 .18 .05],'String',{'No deskew','Spline','Fourier'});
    dat.trimThresh = 335;
    dat.runOnce = true;
end
if ~exist('ard','var') % initalize arduino
    disp('initializing arduino ...')
    ports = serialportlist;
    ard = serialport(ports{end},115200/2,'Timeout',2);
    clear ports;
    readline(ard); % waits for ard to boot
end

while runBtn.Value || dat.runOnce
    writeline(ard,'b'); % pause(.02);
    try
        dat.bin = read(ard,802,'uint16');
        dat.dt = bitshift(dat.bin(802),16)+dat.bin(801); % microseconds
        dat.raw = reshape(dat.bin(1:800),2,400)';
        [dat.data, dat.npds] = trim(dat.raw, dat.trimThresh, -1, 1); % adjust 2nd arg ~ mean(dat.raw)
        dat.t = linspace(0,dat.dt/1000,400)';
        dat.t = dat.t(1:length(dat.data)); 
        dat.sr = length(dat.raw)/dat.dt*1e6; % sample rate (#/sec)
        dat.freq = dat.sr/(length(dat.data)/dat.npds); % Hz, 1/sec
        dat.data = arddeskew(dat.data, dat.skew.String{dat.skew.Value}); 
        dat.fd = fft(dat.data); % data was trimmed to npds 
        dat.ampl = dat.fd(dat.npds+1,:) / length(dat.data) * 2;
        dat.theta = rad2deg(angle(dat.fd(dat.npds+1,:)));
    catch
        flush(ard);
        fprintf('*');
        break;
    end
    plot(dat.t, dat.data, '.-');
    xlabel('msec'); ylabel('ADU'); grid on;
    title(sprintf('%.2fHz V1=%.2f V2 = %.2f deg=%.2f', ...
        dat.freq, abs(dat.ampl), diff(dat.theta)),'FontSize',12);
    displayfps;
    dat.runOnce = false;    % runOnce
end
