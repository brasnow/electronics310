function [d, numperiods] = trim(data, thresh, npds, refchan)
% function [d, numperiods] = trim(data, thresh, npds, refchan);
% trim data to npds starting from the positive going thresh 
% crossing (default: 0) on data(:,refchan). 
% default refchan = data(:,end);
% npds < 1 --> return as many whole ones as possible (default)

% 10apr19 BR
% 15jul21 BR fixed bug returning numperiods
% 20dec23 BR added bailout if < 2 threshold xing

if nargin < 4, refchan = length(data(1,:)); end
if nargin < 3, npds = -1; end
if nargin < 2, thresh = 0; end
a = data(:,refchan) > thresh; % boolean
b = [a(2:end); a(1)]; % shifted
p0x = find(b-a == 1); % positive zero crossing indices
if length(p0x) < 3, d = data; numperiods = 0; return; end
p0x(end) = []; % the last one is length(data), not a p0x. 

if npds < 1 
    d = data(p0x(1):p0x(end)-1,:); 
else
    d = data(p0x(end-npds):p0x(end)-1,:); % take the last ones ... why?
end
if nargout == 2
    if npds == -1
        numperiods = length(p0x)-1;
    else
        numperiods = npds;
    end
end