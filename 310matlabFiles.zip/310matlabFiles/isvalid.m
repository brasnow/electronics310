function bool = isvalid (handle)
  % function bool = isvalid (handle) -- returns true if handle
  % refers to a valid object. This is builtin in Matlab
  bool = true;
  try
    get(handle);
  catch
    bool = false;
  end
end