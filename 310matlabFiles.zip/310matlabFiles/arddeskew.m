function sdata = arddeskew(data, algorithm)
% function sdata = arddeskew(data, algorithm) 
% deskew 2 channel arduino analog data simulating concurrency
% algorithm = 'spline', 'fourier', or 'none' (default)

% 8nov21 BR, major refactor 1 mar 24

    if nargin < 2 || lower(algorithm(1)) == 'n' % none
	    sdata = data; 
	    return; 
    end
    [r, ~] = size(data);
    if lower(algorithm(1)) == 's' % spline shift
        t = (1:r)';
        timeShiftedA1 = spline(t+.5, data(:,2), t);
        % if the first splined data point is way negative, change it ...
        minVal = min(timeShiftedA1(2:end));
        if timeShiftedA1(1) < minVal, timeShiftedA1(1) = minVal; end 
    elseif lower(algorithm(1)) == 'f' % Fourier shift    
        dphase = (1:r/2)' * pi / r; % half of it  
        dphase = [0; dphase; -dphase(end-1+mod(r,2):-1:1)];
        shiftedA1spectra = fft(data(:,2)) .* exp(-1j * dphase);
        timeShiftedA1 = abs(ifft(shiftedA1spectra));
    end 
    sdata = [data(:,1) timeShiftedA1];
end