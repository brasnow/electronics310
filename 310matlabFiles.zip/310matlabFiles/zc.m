function zcapacitor = zc(farad, hz)
% function zcapacitor = zc(farad, hz)
% compute complex impedances of capacitor farad at frequencies hz
% hz can be a vector or matrix, and is persistent
    persistent hzz
    if nargin == 2, hzz = hz; end
    zcapacitor = 1 ./ (1j * 2 * pi * farad * hzz);
end