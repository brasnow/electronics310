function [pwmVal] = freq2pwm(freq, ard)
% function [pwmVal] = freq2pmw(freq, ard)
% return pwm value corresponding to freq (Hz) for XR2206 arduino control
% using the identical current mirror circuit built for the LM317 and
% volts2pwm function
% if a serial port is passes as 2nd arg then sends p command 

% pf = [-2.3136   13.0795  -27.9919  126.0315  -95.0809];
pf = [-0.3166    3.4943  -12.6203  111.2594  -96.3303];
pwmVal = constrain(round(polyval(pf,freq/1e3))+150,0,255);

if nargin == 2, writeline(ard,['p' num2str(pwmVal)]); end
end

function x = constrain(x, xmin, xmax)
% Arduino's constrain function
x(x<xmin) = xmin;
x(x>xmax) = xmax;
end