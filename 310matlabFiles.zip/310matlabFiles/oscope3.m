%% oscope3.m -- added trim, title with freq, ampls, phase diff, and spline deskew
% 16oct22 BR, Arduino running oscope1, command set = b, p
%% initialization
if ~exist('runBtn','var') || ~isvalid(runBtn)  % add the button once
    runBtn = uicontrol('style','radiobutton','string','run','units','normalized',...
        'position',[.13 .93 .1 .04], 'Callback','oscope3');
    skewCtl = uicontrol('Style','popupmenu','Units','normalized',...
        'Position',[.1 .01 .18 .05],'String',{'No deskew','Spline','Fourier'});
end
if ~exist('ard','var') % initalize arduino
    disp('initializing arduino ...')
    ports = serialportlist; % on my computer, arduino is always the last one
    ard = serialport(ports{end}, 57600, 'Timeout', 2);
    clear ports;
    readline(ard); % wait for Arduino to reboot
end
if ~exist('runOnce','var'), runOnce = true; end
%% loop
while runBtn.Value || runOnce
    writeline(ard,'b'); 
    try
        bin = read(ard,802,'uint16');
        dt = bitshift(bin(802),16)+bin(801); % microseconds
        rawdata = reshape(bin(1:800),2,400)';
        [rdata, npds] = trim(rawdata, 340); % adjust 2nd arg = ADU with steepest slope
        t = linspace(0,dt/1000,400)'; % msec
        sr = length(rawdata)/dt*1e6; % sample rate (#/sec)
        freq = sr/(length(rdata)/npds); % Hz, 1/sec
        tt = (1:length(rdata))'; % sample clock
        data = arddeskew(rdata, skewCtl.String{skewCtl.Value}); 
        fd = fft(data);  
        ampl = abs(fd(npds+1,:)) / length(data) * 2;
        theta = rad2deg(angle(fd(npds+1,:)));
        %% display
        plot(t(1:length(data)), data, '.-');
        xlabel('msec'); ylabel('ADU'); grid on;
        title(sprintf('%.2fHz V1=%.2f V2 = %.2f deg=%.2f', ...
            freq, ampl, diff(theta)),'FontSize',12);
    catch
        flush(ard);
        fprintf('*');
    end
    displayfps;
    runOnce = false;
end