function [zl] = zl(henry, hz)
% function zl = zl(henry, hz)
% compute complex impedances of inductor henry at frequencies hz
% hz can be a vector or matrix, and is persistent

% 7 apr 21 BR

persistent hzz
if nargin == 2, hzz = hz; end
j = sqrt(-1);
zl = j*2*pi*henry*hzz;
end