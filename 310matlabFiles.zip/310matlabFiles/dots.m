% function dots(marker)		12 oct 98 BR
% dots -- set the marker on the current axis to dots (default)
% marker can be 'none', or any valid char

function dots(marker)
if nargin == 0
    marker = '.';
end
h = get(gca, 'Children');
for i=1:length(h)
    if strcmp(get(h(i),'Type'),'line')
        set(h(i),'Marker', marker);
    end
end
figure(gcf);
end

