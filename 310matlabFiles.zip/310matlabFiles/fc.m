function fcorner = fc(R,C)
% function fcorner = fc(R,C)
% return the corner = cutoff frequency (Hz) for an RC circuit
% with R(ohms) and C(farads)
% time constant tau = RC, corner omega = 1/tau = 2*pi*fc

% 16 mar 23 BR
fcorner = 1/(2*pi*R*C);
end