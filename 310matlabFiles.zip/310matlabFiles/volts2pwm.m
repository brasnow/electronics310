function [pwmVal] = volts2pwm(volts, ard)
% function [pwmVal] = volts2pwm(volts, ard)
% return pwm value corresponding to volts for LM317 arduino ...
% if a serial port is passes as 2nd arg then sends p command 

% pv = [-0.0526    0.9434  -24.7402  281.5264];
% pv = [-0.0438    0.9319  -23.7911  273.4372]; 
pv = [-0.0450    0.8010  -22.9973  277.6989];
pwmVal = round(polyval(pv, volts));
pwmVal(pwmVal < 0) = 0;
pwmVal(pwmVal > 255) = 255;
if nargin == 2
    writeline(ard,['p' num2str(pwmVal)]);
end
end