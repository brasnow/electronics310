
% startup.m -- executes when Matlab launches

%% live script exports default to eps (and mess up) if the script has been run
% if it hasn't been run, they default to png and are sized ok. 
% other options are 'jpg' and 'pdf' 
% 11jan23 BR
s = settings;
s.matlab.editor.export.latex.FigureFormat.TemporaryValue = 'jpeg';
s.matlab.editor.export.latex.FigureFormat.PersonalValue = 'jpeg';
s.matlab.editor.export.latex.FigureResolution.TemporaryValue=1200;
s.matlab.editor.export.latex.FigureResolution.PersonalValue=1200;
clear s
%% set fonts and default color order to RGB ....
% whitebg(0, [1 1 1]);
 set(0,'DefaultAxesFontName','Lucida Bright');
 set(0,'DefaultTextFontName','Lucida Bright');
set(0,'DefaultAxesFontSize',14);
set(0,'DefaultTextFontSize',14)
c = [... % red green blue cyan magenta yellow gray black
    1    0     0
    0    0.7   0
    0    0     1
    0    1     1
    1    0     1
    1    0.95  0
    .5    .5   .5
    0    0     0];
set(0,'DefaultAxesColorOrder', c);
set(0,'DefaultAxesColor', [1 1 1])
set(0,'DefaultAxesLineStyleOrder','-|--|:|-.')
set(0,'DefaultUIControlBackgroundColor','white');
set(0,'DefaultFigureColor',[1 1 1]);
set(0,'defaultsurfaceedgecolor',[0 0 0])
set(0,'DefaultFigureColormap',jet)
% set(0,'DefaultFigurePosition',[4054 806 560 420]); % for 2 screen mbp
format compact
clear c
more on;

set(0,'defaultLineLineWidth',1); % to make grids dotted (why??)
