%% oscope3.m -- added title with freq, ampls, phase diff, and spline deskew
%% oscope2.m -- added trim for triggering
%% script oscope1.m -- first version of an Arduino oscilloscope display
% 16oct22 BR, Arduino running oscope1, command set = b, p, s
if ~exist('runBtn','var') || ~isvalid(runBtn)  % add the button once
    runBtn = uicontrol('style','radiobutton','string','run','units', ...
        'normalized','position',[.13 .93 .1 .04]);
    runBtn.Callback = 'pscope3';
end
if ~exist('ard','var') % initalize arduino
    disp('initializing arduino ...')
    ports = serialportlist;
    ard = serialport(ports{end},115200);
    ard.Timeout = 1;
    clear ports;
    pause(2); % time to boot
end
if ~exist('runOnce','var'), runOnce = true; end

while runBtn.Value || runOnce
    writeline(ard,'b'); pause(.1);
    try
        bin = read(ard,2002,'uint16');
        dt = bitshift(bin(2002),16)+bin(2001); % microseconds
        rawdata = reshape(bin(1:2000),2,1000)';
        [rdata, npds] = trim(rawdata, 620); % adjust 2nd arg = ADU with steepest slope
        t = linspace(0,dt/1000,1000)';
        t = t(1:length(rdata)); 
        sr = length(rawdata)/dt*1e6; % sample rate (#/sec)
        freq = sr/(length(rdata)/npds); % Hz, 1/sec
        
        data = arddeskew(rdata, 'spline');
        % data = arddeskew(rdata, 'fourier');
        % if the first splined data point is way negative, change it ...
        if data(1,2) < min(data(2:end,2)), data(1,2) = min(data(2:end,2)); end 
        fd = fft(data); % data is trimmed to npds 
        ampl = abs(fd(npds+1,:)) / length(data) * 2;
        theta = rad2deg(angle(fd(npds+1,:)));
        plot(t, data, '.-');
        xlabel('msec'); ylabel('ADU'); grid on;
        title(sprintf('%.2fHz V1=%.2f V2 = %.2f deg=%.2f', ...
            freq, ampl, diff(theta)),'FontSize',12);
        displayfps;
    catch
        flush(ard);
        fprintf('*');
        break;
    end
    runOnce = false;
end
