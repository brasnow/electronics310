%% script oscope2.m -- 2nd version of an Arduino oscilloscope display
% 3jan23 BR, Arduino running oscope1.ino, command set = b and p

if ~exist('runBtn','var') || ~isvalid(runBtn) % add the button
    runBtn = uicontrol('style','radiobutton','string','run','units', ...
        'normalized','position',[.13 .93 .1 .04],'Callback', 'oscope2');
end
if ~exist('ard','var') % initalize arduino
    disp('initializing arduino ...')
    ports = serialportlist; % works for me, substitute appropriate port for yours
    ard = serialport(ports(end),115200/2,'Timeout',2); 
    clear ports; % clean up workspace
    readline(ard); % waits for ard to boot
    vref = input('enter vref (volts): ');
end
if ~exist('runOnce','var'), runOnce = true; end

while runBtn.Value || runOnce
    writeline(ard,'b'); pause(.01);
    try
        bin = read(ard,802,'uint16');
        data = reshape(bin(1:800),2,400)';
        dt = bitshift(bin(802),16)+bin(801); % microseconds
        
        % sr = length(data)/dt*1e6; % sample rate (#/sec)
        % aspectrum(data, sr);

        t = linspace(0,dt/1000,400)';
        plot(t, data, '.-'); grid;
        xlabel('msec'); ylabel('ADU')
    catch
        flush(ard);
        fprintf('*');
    end
    runOnce = false;
    displayfps;
end