function [rp] = rp(r1,r2)
% resistance in parallel of 2 resistors

% Sept 4 2024 B.R.

rp = r1 * r2 / (r1+r2);
end